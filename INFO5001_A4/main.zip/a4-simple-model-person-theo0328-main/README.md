## Simple Model Assignment

### Part 1

Complete the code inside the classes (`Address`, `Phone`, `Person`) as per description inside each class.

### Part 2

Inside the `main` method create instances of 5 people and add their addresses and phone numbers

### Part 3

Print all the information to the console. (hint: you can use `System.out.println()` to print to console).