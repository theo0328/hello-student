package model;

public class Address {
    /*
     * Part 1.1
     * 
     * Add the following properties:
     * - Line one
     * - Line two
     * - Zip code
     * - City
     * - State
     * - Country
     */

    // Add getter and setter methods for EVERY attribute
}
