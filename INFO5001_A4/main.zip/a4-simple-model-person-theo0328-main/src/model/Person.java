package model;

public class Person {
    /*
     * Part 1.3
     * 
     * Add the following properties:
     * - First name
     * - Last name
     * - Home address
     * - Work address
     * - Cell phone number
     * - Home phone number
     */

    // Add getter and setter methods for EVERY attribute
}
