package model;

public class Phone {
    /*
     * Part 1.2
     *
     * Add the following properties:
     * - String country code
     * - String area code
     * - String phone number
     */

    // Add getter and setter methods for EVERY attribute
}
