## Campus Model

See assignment description in CampusMainExample.

## IMPORTANT

Be aware that initial code contains some missing pieces and therefore shows errors.